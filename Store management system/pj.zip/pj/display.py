def front(): 
    print(" 1. For Renting ")
    print(" 2. For returning ")
    print(" 3. For exit ")
    print(" 4. Display available lands for renting ")

def error():
    print("Error occurred while writing bill file.")
